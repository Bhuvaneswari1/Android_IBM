package com.example.json_retrofit_parse_parameters;

public class JSONResponse {
    private AndroidVersion[] android;

    public AndroidVersion[] getAndroid() {
        return android;
    }
}
