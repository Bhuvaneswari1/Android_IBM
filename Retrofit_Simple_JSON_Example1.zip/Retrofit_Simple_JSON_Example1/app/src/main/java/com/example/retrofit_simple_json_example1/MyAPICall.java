package com.example.retrofit_simple_json_example1;

public interface MyAPICall {
}
