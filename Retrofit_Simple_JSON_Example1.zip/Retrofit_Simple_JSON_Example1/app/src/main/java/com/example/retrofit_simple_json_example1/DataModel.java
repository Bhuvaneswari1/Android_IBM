package com.example.retrofit_simple_json_example1;

public class DataModel {

    //This class will be as a template for the data that we are going to parse

    private int userId;
    private int id;
    private String title;

    private boolean completed;

    //Getter Method


    public int getUserId() {
        return userId;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public boolean isCompleted() {
        return completed;
    }
}
