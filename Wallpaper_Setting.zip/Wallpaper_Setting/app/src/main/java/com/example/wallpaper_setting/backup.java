package com.example.wallpaper_setting;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;

public class backup extends Activity implements View.OnClickListener {
    ImageView display;
    int tophone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        // to our activity to cover the whole screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.backup);
        Button but = (Button) findViewById(R.id.setwallpaper);
        tophone = R.mipmap.road;
        but.setOnClickListener(this);
        display = (ImageView) findViewById(R.id.ivdisplay);
        ImageView image1 = (ImageView) findViewById(R.id.IVimage1);
        ImageView image2 = (ImageView) findViewById(R.id.IVimage2);
        ImageView image3 = (ImageView) findViewById(R.id.IVimage3);
        ImageView image4 = (ImageView) findViewById(R.id.image4);
        ImageView image5 = (ImageView) findViewById(R.id.IVimage5);

        image1.setOnClickListener(this);
        image2.setOnClickListener(this);
        image3.setOnClickListener(this);
        image4.setOnClickListener(this);
        image5.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        Toast var;
        switch (view.getId()) {
            case R.id.IVimage1:
                display.setImageResource(R.mipmap.bike);
                var = Toast.makeText(backup.this, "image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                tophone = R.mipmap.bike;
                break;
            case R.id.IVimage2:
                display.setImageResource(R.mipmap.blur);
                var = Toast.makeText(backup.this, "image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                tophone = R.mipmap.blur;
                break;
            case R.id.IVimage3:
                display.setImageResource(R.mipmap.flowers);
                var = Toast.makeText(backup.this, "image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                tophone = R.mipmap.flowers;
                break;
            case R.id.image4:
                display.setImageResource(R.mipmap.nature);
                var = Toast.makeText(backup.this, "image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                tophone = R.mipmap.nature;
                break;
            case R.id.IVimage5:
                display.setImageResource(R.mipmap.photography);
                var = Toast.makeText(backup.this, "image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                tophone = R.mipmap.photography;
                break;
            case R.id.setwallpaper:
                // to set a background we need to use bitmap
                InputStream is = getResources().openRawResource(tophone);
                // tophone is a variable that is updated everytime we click on an
                // ImageView to that imageview resource and by clicking the button
                // we set the phone background to that image.
                Bitmap bm = BitmapFactory.decodeStream(is);
                // decode inputstream is
                try {
                    getApplicationContext().setWallpaper(bm);
                    // to set the wallpaper of the phone background we need to ask
                    // permission from the user so add permission of background from
                    // manifest file

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                var = Toast.makeText(backup.this, "Wallpaper image changed",
                        Toast.LENGTH_SHORT);
                var.show();
                break;
        }
    }
}
