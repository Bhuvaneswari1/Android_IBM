package com.example.retrofit_new_example1;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {
    private static RetrofitClient instance = null;
    private Api myApi;

    private RetrofitClient() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        myApi = retrofit.create(Api.class);
    }

    public static synchronized RetrofitClient getInstance() {
        if (instance == null) {
            instance = new RetrofitClient();
        }
        return instance;
    }

    public Api getMyApi() {
        return myApi;
    }

}
//Use of GsonConverterFactory in Retrofit - Retrofit is a very popular HTTP client library for Android. Using Retrofit makes it
//easy to parse API response and use it in your application. It has built-in GSON converter that can automatically parse
//HTTP response into an object or any other types in Java that can be used in your code.
